import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ArrowRight, RotateCcw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { destinations } from "@shared/schema";
import { Link } from "wouter";

const questions = [
  {
    id: 1,
    text: "Quelle est votre ambiance idéale ?",
    options: [
      { label: "Raffinée et artistique", value: "art" },
      { label: "Sauvage et intense", value: "nature" },
      { label: "Festive et innovante", value: "party" },
    ],
  },
  {
    id: 2,
    text: "Quel niveau de danger tolérez-vous ?",
    options: [
      { label: "Aucun, je veux me détendre", value: "low" },
      { label: "Un peu d'adrénaline", value: "medium" },
      { label: "Je suis prêt à courir pour ma vie", value: "high" },
    ],
  },
  {
    id: 3,
    text: "Qu'emportez-vous dans votre valise ?",
    options: [
      { label: "Un carnet de croquis", value: "sketch" },
      { label: "Une tenue de soirée", value: "tuxedo" },
      { label: "Un kit de survie", value: "survival" },
    ],
  },
  {
    id: 4,
    text: "Votre but ultime ?",
    options: [
      { label: "Voir un chef d'œuvre naître", value: "create" },
      { label: "Comprendre le passé", value: "learn" },
      { label: "Vivre l'impossible", value: "experience" },
    ],
  },
];

export default function TravelQuiz() {
  const [currentStep, setCurrentStep] = useState(0);
  const [answers, setAnswers] = useState<string[]>([]);
  const [result, setResult] = useState<typeof destinations[0] | null>(null);

  const handleAnswer = (value: string) => {
    const newAnswers = [...answers, value];
    setAnswers(newAnswers);

    if (currentStep < questions.length - 1) {
      setCurrentStep(currentStep + 1);
    } else {
      calculateResult(newAnswers);
    }
  };

  const calculateResult = (finalAnswers: string[]) => {
    // Simple logic for demo purposes
    if (finalAnswers.includes("high") || finalAnswers.includes("nature")) {
      setResult(destinations.find(d => d.slug === "cretace") || destinations[0]);
    } else if (finalAnswers.includes("art") || finalAnswers.includes("create")) {
      setResult(destinations.find(d => d.slug === "florence-1504") || destinations[0]);
    } else {
      setResult(destinations.find(d => d.slug === "paris-1889") || destinations[0]);
    }
  };

  const resetQuiz = () => {
    setCurrentStep(0);
    setAnswers([]);
    setResult(null);
  };

  return (
    <div className="w-full max-w-2xl mx-auto bg-card/30 backdrop-blur-md rounded-3xl border border-white/5 p-8 md:p-12 relative overflow-hidden">
      {/* Decorative background elements */}
      <div className="absolute top-0 right-0 w-64 h-64 bg-primary/5 rounded-full blur-3xl -z-10" />
      <div className="absolute bottom-0 left-0 w-64 h-64 bg-blue-500/5 rounded-full blur-3xl -z-10" />

      <h2 className="font-display text-3xl md:text-4xl font-bold text-center mb-8 text-gradient-gold">
        Trouvez votre époque
      </h2>

      <AnimatePresence mode="wait">
        {!result ? (
          <motion.div
            key={currentStep}
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            className="space-y-8"
          >
            <div className="flex justify-between items-center text-sm text-muted-foreground uppercase tracking-widest">
              <span>Question {currentStep + 1} / {questions.length}</span>
              <div className="flex gap-1">
                {questions.map((_, i) => (
                  <div 
                    key={i} 
                    className={`h-1 w-8 rounded-full transition-colors ${i <= currentStep ? 'bg-primary' : 'bg-white/10'}`} 
                  />
                ))}
              </div>
            </div>

            <h3 className="text-2xl font-light text-center">
              {questions[currentStep].text}
            </h3>

            <div className="grid gap-4">
              {questions[currentStep].options.map((option) => (
                <button
                  key={option.value}
                  onClick={() => handleAnswer(option.value)}
                  className="p-4 rounded-xl border border-white/10 bg-white/5 hover:bg-primary/20 hover:border-primary/50 hover:scale-[1.02] active:scale-[0.98] transition-all duration-200 text-left group"
                >
                  <span className="text-lg group-hover:text-primary transition-colors">{option.label}</span>
                </button>
              ))}
            </div>
          </motion.div>
        ) : (
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="text-center space-y-8"
          >
            <div className="w-20 h-20 mx-auto bg-primary/20 rounded-full flex items-center justify-center">
              <span className="text-4xl">✨</span>
            </div>
            
            <div>
              <p className="text-muted-foreground mb-2">Votre destination idéale est...</p>
              <h3 className="font-display text-4xl font-bold text-primary mb-4">{result.title}</h3>
              <p className="text-gray-300 max-w-md mx-auto">{result.description}</p>
            </div>

            <div className="flex flex-col sm:flex-row gap-4 justify-center pt-4">
              <Link href={`/book?destination=${result.slug}`}>
                <Button size="lg" className="bg-primary text-black hover:bg-primary/90 font-bold px-8 w-full sm:w-auto">
                  Réserver maintenant
                </Button>
              </Link>
              <Button 
                variant="outline" 
                size="lg" 
                onClick={resetQuiz}
                className="border-white/10 hover:bg-white/5 text-white w-full sm:w-auto gap-2"
              >
                <RotateCcw className="w-4 h-4" /> Recommencer
              </Button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
