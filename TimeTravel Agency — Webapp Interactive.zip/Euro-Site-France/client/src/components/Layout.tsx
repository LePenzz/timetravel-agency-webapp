import { Link, useLocation } from "wouter";
import { motion } from "framer-motion";
import { Menu, X, Clock, Map, Info, BookOpen } from "lucide-react";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import ChatWidget from "./ChatWidget";

export default function Layout({ children }: { children: React.ReactNode }) {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [location] = useLocation();

  const navLinks = [
    { href: "/", label: "Accueil", icon: Clock },
    { href: "/destinations", label: "Destinations", icon: Map },
    { href: "/about", label: "À propos", icon: Info },
    { href: "/book", label: "Réserver", icon: BookOpen },
  ];

  return (
    <div className="min-h-screen flex flex-col bg-background text-foreground overflow-x-hidden font-sans">
      <header className="fixed top-0 left-0 right-0 z-50 glass border-b border-white/5">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-20">
            {/* Logo */}
            <Link href="/" className="flex items-center gap-3 group cursor-pointer">
              <div className="w-10 h-10 rounded-full bg-gradient-to-br from-primary to-amber-700 flex items-center justify-center shadow-lg shadow-primary/20 group-hover:scale-110 transition-transform duration-300">
                <Clock className="w-6 h-6 text-black" />
              </div>
              <span className="font-display text-2xl font-bold tracking-wider text-gradient-gold">
                CHRONOS
              </span>
            </Link>

            {/* Desktop Nav */}
            <nav className="hidden md:flex items-center gap-8">
              {navLinks.map((link) => (
                <Link key={link.href} href={link.href}>
                  <span
                    className={`text-sm font-medium tracking-wide uppercase transition-colors duration-200 hover:text-primary cursor-pointer flex items-center gap-2 ${
                      location === link.href ? "text-primary" : "text-muted-foreground"
                    }`}
                  >
                    {link.label}
                  </span>
                </Link>
              ))}
              <Link href="/book">
                <Button className="bg-primary text-black hover:bg-primary/90 font-bold px-6">
                  Voyager
                </Button>
              </Link>
            </nav>

            {/* Mobile Menu Button */}
            <button
              className="md:hidden p-2 text-foreground"
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            >
              {isMobileMenuOpen ? <X /> : <Menu />}
            </button>
          </div>
        </div>

        {/* Mobile Menu */}
        {isMobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="md:hidden glass border-t border-white/5 absolute w-full"
          >
            <div className="px-4 py-6 space-y-4">
              {navLinks.map((link) => (
                <Link key={link.href} href={link.href}>
                  <span
                    className="block py-2 text-lg font-medium hover:text-primary cursor-pointer"
                    onClick={() => setIsMobileMenuOpen(false)}
                  >
                    <div className="flex items-center gap-3">
                      <link.icon className="w-5 h-5" />
                      {link.label}
                    </div>
                  </span>
                </Link>
              ))}
            </div>
          </motion.div>
        )}
      </header>

      <main className="flex-grow pt-20 relative">
        {children}
      </main>

      <footer className="bg-black border-t border-white/10 py-12 mt-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
            <div>
              <h3 className="font-display text-2xl font-bold text-primary mb-4">CHRONOS</h3>
              <p className="text-muted-foreground leading-relaxed">
                L'agence de voyage temporel de référence. 
                Nous transformons l'histoire en votre destination.
                Sécurité garantie par le Protocole Temporel™.
              </p>
            </div>
            <div>
              <h4 className="font-bold mb-4 uppercase tracking-wider text-sm">Liens Rapides</h4>
              <ul className="space-y-2">
                <li><Link href="/destinations" className="text-muted-foreground hover:text-primary transition-colors">Destinations</Link></li>
                <li><Link href="/about" className="text-muted-foreground hover:text-primary transition-colors">Le Protocole</Link></li>
                <li><Link href="/book" className="text-muted-foreground hover:text-primary transition-colors">Réservation</Link></li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold mb-4 uppercase tracking-wider text-sm">Contact</h4>
              <p className="text-muted-foreground">
                Siège social : Paris, 2024<br />
                QG Temporel : Hors du temps<br />
                contact@chronos.time
              </p>
            </div>
          </div>
          <div className="border-t border-white/10 mt-12 pt-8 text-center text-sm text-muted-foreground">
            © 2024 Chronos Travel Agency. Tous droits réservés dans toutes les timelines.
          </div>
        </div>
      </footer>

      <ChatWidget />
    </div>
  );
}
