import { Link } from "wouter";
import { motion } from "framer-motion";
import { Calendar, Cloud, ShieldAlert, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import type { destinations } from "@shared/schema";

type Destination = typeof destinations[number];

export default function DestinationCard({ destination }: { destination: Destination }) {
  return (
    <motion.div
      whileHover={{ y: -5 }}
      className="group relative overflow-hidden rounded-2xl bg-card border border-white/5 shadow-xl"
    >
      {/* Image Background */}
      <div className="aspect-[4/5] md:aspect-[3/4] overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-t from-black via-black/50 to-transparent z-10 opacity-80 group-hover:opacity-90 transition-opacity duration-500" />
        {/* Unsplash image with descriptive comment */}
        {/* Destination image based on era/theme */}
        <img
          src={destination.image}
          alt={destination.title}
          className="w-full h-full object-cover transform group-hover:scale-110 transition-transform duration-700 ease-out"
        />
      </div>

      {/* Content Overlay */}
      <div className="absolute inset-0 z-20 p-6 flex flex-col justify-end">
        <div className="transform translate-y-4 group-hover:translate-y-0 transition-transform duration-300">
          <div className="mb-2">
            <span className="inline-block px-3 py-1 text-xs font-bold uppercase tracking-widest text-primary bg-primary/10 rounded-full border border-primary/20 backdrop-blur-md">
              {destination.era}
            </span>
          </div>
          
          <h3 className="font-display text-3xl font-bold mb-2 text-white group-hover:text-primary transition-colors">
            {destination.title}
          </h3>

          <div className="flex flex-wrap gap-4 text-sm text-gray-300 mb-4 opacity-0 group-hover:opacity-100 transition-opacity duration-300 delay-100 h-0 group-hover:h-auto overflow-hidden">
            <div className="flex items-center gap-1">
              <Calendar className="w-4 h-4 text-primary" />
              <span>{destination.duration}</span>
            </div>
            <div className="flex items-center gap-1">
              <Cloud className="w-4 h-4 text-primary" />
              <span>{destination.weather}</span>
            </div>
            <div className="flex items-center gap-1">
              <ShieldAlert className="w-4 h-4 text-primary" />
              <span>Risque: {destination.riskLevel}</span>
            </div>
          </div>

          <p className="text-gray-400 text-sm line-clamp-2 mb-6 opacity-0 group-hover:opacity-100 transition-opacity duration-300 delay-150 h-0 group-hover:h-auto">
            {destination.description}
          </p>

          <div className="flex items-center justify-between opacity-0 group-hover:opacity-100 transition-opacity duration-300 delay-200">
            <span className="text-xl font-bold text-white">
              {destination.basePrice.toLocaleString('fr-FR')} €
            </span>
            <Link href={`/destinations/${destination.slug}`}>
              <Button size="sm" className="bg-white/10 hover:bg-white/20 text-white border-none backdrop-blur-md gap-2">
                Explorer <ArrowRight className="w-4 h-4" />
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </motion.div>
  );
}
