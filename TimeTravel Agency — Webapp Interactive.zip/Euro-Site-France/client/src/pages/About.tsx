import { motion } from "framer-motion";
import { Shield, Clock, Globe, Award } from "lucide-react";

export default function About() {
  return (
    <div className="min-h-screen pt-12 pb-24">
      {/* Header */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-20 text-center">
        <motion.h1 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="font-display text-5xl md:text-6xl font-bold mb-6 text-gradient-gold"
        >
          À propos de Chronos
        </motion.h1>
        <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
          Depuis 2154, nous sommes les pionniers du tourisme temporel responsable.
          Notre mission : rendre l'histoire accessible sans la compromettre.
        </p>
      </div>

      {/* Values */}
      <div className="bg-white/5 py-20 border-y border-white/5">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-12">
            {[
              { icon: Shield, title: "Sécurité", text: "Zéro accident en 50 ans d'exploitation." },
              { icon: Clock, title: "Précision", text: "Arrivée à la seconde près, garantie." },
              { icon: Globe, title: "Authenticité", text: "Immersion culturelle totale." },
              { icon: Award, title: "Excellence", text: "Élu meilleure agence 5 années de suite." }
            ].map((item, i) => (
              <motion.div 
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="text-center"
              >
                <div className="w-16 h-16 mx-auto bg-primary/10 rounded-full flex items-center justify-center mb-6">
                  <item.icon className="w-8 h-8 text-primary" />
                </div>
                <h3 className="font-display font-bold text-xl mb-3">{item.title}</h3>
                <p className="text-muted-foreground">{item.text}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </div>

      {/* Protocol Section */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-20">
        <div className="grid md:grid-cols-2 gap-16 items-center">
          <div>
            <h2 className="font-display text-4xl font-bold mb-6">Temporal Protocol™</h2>
            <div className="space-y-6 text-lg text-gray-300">
              <p>
                Le voyage temporel n'est pas un jeu. C'est pourquoi nous avons développé le protocole de sécurité le plus strict de l'industrie.
              </p>
              <ul className="space-y-4">
                <li className="flex gap-4">
                  <span className="font-bold text-primary text-xl">01.</span>
                  <span>Invisibilité causale : nos voyageurs n'interfèrent jamais avec les événements majeurs.</span>
                </li>
                <li className="flex gap-4">
                  <span className="font-bold text-primary text-xl">02.</span>
                  <span>Bio-adaptation : traitements préventifs contre les pathogènes disparus.</span>
                </li>
                <li className="flex gap-4">
                  <span className="font-bold text-primary text-xl">03.</span>
                  <span>Équipement anachronique masqué : votre technologie est invisible aux yeux des locaux.</span>
                </li>
              </ul>
            </div>
          </div>
          <div className="relative h-[500px] rounded-2xl overflow-hidden shadow-2xl border border-white/10">
            {/* Abstract tech/security image */}
            <img 
              src="https://images.unsplash.com/photo-1550751827-4bd374c3f58b?q=80&w=2070&auto=format&fit=crop" 
              alt="Temporal Technology" 
              className="absolute inset-0 w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-background via-transparent to-transparent" />
          </div>
        </div>
      </div>
    </div>
  );
}
