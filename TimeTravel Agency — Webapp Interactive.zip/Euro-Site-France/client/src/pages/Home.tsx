import { motion } from "framer-motion";
import { ArrowRight, Star, ShieldCheck, History } from "lucide-react";
import { Link } from "wouter";
import { destinations } from "@shared/schema";
import DestinationCard from "@/components/DestinationCard";
import TravelQuiz from "@/components/TravelQuiz";
import { Button } from "@/components/ui/button";

export default function Home() {
  return (
    <div className="space-y-24 pb-24">
      {/* Hero Section */}
      <section className="relative h-[90vh] flex items-center justify-center overflow-hidden">
        {/* Background Video/Image */}
        <div className="absolute inset-0 z-0">
          <div className="absolute inset-0 bg-gradient-to-b from-background/80 via-background/40 to-background z-10" />
          {/* Abstract time travel tunnel or historical montage */}
          <img 
            src="https://images.unsplash.com/photo-1447069387593-a5de0862481e?q=80&w=2069&auto=format&fit=crop" 
            alt="Time Travel Tunnel" 
            className="w-full h-full object-cover opacity-50"
          />
        </div>

        <div className="relative z-20 max-w-5xl mx-auto px-4 text-center space-y-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <span className="inline-block px-4 py-1.5 mb-6 text-sm font-bold tracking-[0.2em] uppercase text-primary border border-primary/30 rounded-full bg-primary/5 backdrop-blur-sm">
              L'Histoire vous attend
            </span>
            <h1 className="font-display text-5xl md:text-7xl lg:text-8xl font-bold leading-tight mb-6">
              Voyagez à travers <br />
              <span className="text-gradient-gold">le temps</span>
            </h1>
            <p className="text-xl md:text-2xl text-gray-300 max-w-2xl mx-auto leading-relaxed">
              Vivez l'histoire, ne vous contentez pas de la lire. 
              Des dinosaures à la Renaissance, l'aventure ultime commence ici.
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="flex flex-col sm:flex-row gap-4 justify-center items-center"
          >
            <Link href="/destinations">
              <Button size="lg" className="h-14 px-8 text-lg font-bold bg-primary text-black hover:bg-primary/90 rounded-full">
                Découvrir les époques
              </Button>
            </Link>
            <Link href="/about">
              <Button size="lg" variant="outline" className="h-14 px-8 text-lg font-medium text-white border-white/20 hover:bg-white/10 rounded-full">
                Notre technologie
              </Button>
            </Link>
          </motion.div>
        </div>
      </section>

      {/* Features Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {[
            {
              icon: History,
              title: "Immersion Totale",
              desc: "Costumes d'époque, monnaie locale et formation linguistique inclus."
            },
            {
              icon: ShieldCheck,
              title: "Sécurité Maximale",
              desc: "Notre Protocole Temporel™ assure votre sécurité et l'intégrité de l'histoire."
            },
            {
              icon: Star,
              title: "Service Premium",
              desc: "Hébergement de luxe anachronique et guide personnel 24/7."
            }
          ].map((feature, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.2 }}
              className="p-8 rounded-2xl bg-white/5 border border-white/5 hover:border-primary/30 transition-colors text-center group"
            >
              <div className="w-16 h-16 mx-auto mb-6 bg-primary/10 rounded-full flex items-center justify-center group-hover:scale-110 transition-transform duration-300">
                <feature.icon className="w-8 h-8 text-primary" />
              </div>
              <h3 className="text-xl font-bold mb-3 font-display">{feature.title}</h3>
              <p className="text-muted-foreground">{feature.desc}</p>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Destinations Preview */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-end mb-12">
          <div>
            <h2 className="font-display text-4xl font-bold mb-2">Destinations Populaires</h2>
            <p className="text-muted-foreground">Les époques les plus prisées par nos voyageurs.</p>
          </div>
          <Link href="/destinations">
            <Button variant="ghost" className="hidden md:flex gap-2 text-primary hover:text-primary/80">
              Tout voir <ArrowRight className="w-4 h-4" />
            </Button>
          </Link>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {destinations.map((dest) => (
            <DestinationCard key={dest.id} destination={dest} />
          ))}
        </div>

        <div className="mt-8 text-center md:hidden">
          <Link href="/destinations">
            <Button variant="outline" className="w-full border-primary/20 text-primary">
              Voir toutes les destinations
            </Button>
          </Link>
        </div>
      </section>

      {/* Quiz Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <TravelQuiz />
      </section>
    </div>
  );
}
