import { Link } from "wouter";
import { AlertTriangle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";

export default function NotFound() {
  return (
    <div className="min-h-[80vh] w-full flex items-center justify-center bg-background p-4">
      <Card className="w-full max-w-md bg-card border-white/10">
        <CardContent className="pt-6 text-center space-y-6">
          <div className="flex justify-center">
            <AlertTriangle className="h-16 w-16 text-primary animate-pulse" />
          </div>
          
          <div className="space-y-2">
            <h1 className="text-4xl font-display font-bold text-foreground">404</h1>
            <h2 className="text-xl font-semibold text-primary">Faille Temporelle Détectée</h2>
            <p className="text-muted-foreground">
              La timeline que vous recherchez n'existe pas ou a été effacée du continuum espace-temps.
            </p>
          </div>

          <Link href="/">
            <Button className="w-full bg-primary text-black hover:bg-primary/90 font-bold">
              Retour au Présent
            </Button>
          </Link>
        </CardContent>
      </Card>
    </div>
  );
}
