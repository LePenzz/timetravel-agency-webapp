import { motion } from "framer-motion";
import { destinations } from "@shared/schema";
import DestinationCard from "@/components/DestinationCard";

export default function Destinations() {
  return (
    <div className="min-h-screen pt-12 pb-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="font-display text-5xl md:text-6xl font-bold mb-6 text-gradient-gold"
          >
            Le Catalogue Temporel
          </motion.h1>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="text-xl text-muted-foreground"
          >
            Choisissez votre époque parmi notre sélection rigoureuse de moments clés de l'histoire.
            Chaque destination a été sécurisée et préparée pour votre visite.
          </motion.p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {destinations.map((dest, i) => (
            <motion.div
              key={dest.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.1 + 0.2 }}
            >
              <DestinationCard destination={dest} />
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}
