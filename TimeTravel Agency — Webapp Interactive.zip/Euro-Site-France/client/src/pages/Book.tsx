import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { motion } from "framer-motion";
import { Calendar as CalendarIcon, Users, Star, ArrowRight, Check } from "lucide-react";
import { format } from "date-fns";
import { fr } from "date-fns/locale";

import { insertBookingSchema, destinations } from "@shared/schema";
import { useCreateBooking } from "@/hooks/use-bookings";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Card, CardContent } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useToast } from "@/hooks/use-toast";

const preferencesOptions = [
  { id: "art", label: "Art & Culture" },
  { id: "nature", label: "Nature & Paysages" },
  { id: "gastronomy", label: "Gastronomie Historique" },
  { id: "architecture", label: "Architecture" },
  { id: "adventure", label: "Aventure & Action" },
];

export default function Book() {
  const [location, setLocation] = useLocation();
  const [success, setSuccess] = useState(false);
  const searchParams = new URLSearchParams(window.location.search);
  const initialDestination = searchParams.get("destination") || "";
  
  const createBooking = useCreateBooking();
  const { toast } = useToast();

  const form = useForm({
    resolver: zodResolver(insertBookingSchema),
    defaultValues: {
      destinationId: initialDestination,
      startDate: format(new Date(), "yyyy-MM-dd"),
      endDate: format(new Date(Date.now() + 7 * 24 * 60 * 60 * 1000), "yyyy-MM-dd"),
      groupSize: 1,
      comfortLevel: "premium",
      preferences: [],
    },
  });

  const onSubmit = (data: any) => {
    createBooking.mutate(data, {
      onSuccess: () => {
        setSuccess(true);
        window.scrollTo({ top: 0, behavior: 'smooth' });
      }
    });
  };

  if (success) {
    return (
      <div className="min-h-[80vh] flex items-center justify-center p-4">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          className="max-w-md w-full text-center space-y-6"
        >
          <div className="w-24 h-24 mx-auto bg-green-500/20 rounded-full flex items-center justify-center mb-6">
            <Check className="w-12 h-12 text-green-500" />
          </div>
          <h1 className="font-display text-4xl font-bold text-gradient-gold">Voyage Confirmé</h1>
          <p className="text-xl text-muted-foreground">
            Votre réservation a été enregistrée. Nos agents temporels vous contacteront sous peu pour le briefing de sécurité.
          </p>
          <Button onClick={() => setLocation('/')} size="lg" className="mt-8 bg-primary text-black hover:bg-primary/90">
            Retour à l'accueil
          </Button>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen pt-12 pb-24">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h1 className="font-display text-4xl md:text-5xl font-bold mb-4">Réservez votre Voyage</h1>
          <p className="text-muted-foreground">Remplissez ce formulaire pour initialiser la procédure de transfert temporel.</p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {/* Form */}
          <div className="md:col-span-2">
            <Card className="bg-card border-white/10">
              <CardContent className="p-6 md:p-8">
                <Form {...form}>
                  <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
                    
                    <div className="space-y-4">
                      <h3 className="text-xl font-bold font-display flex items-center gap-2">
                        <span className="w-8 h-8 rounded-full bg-primary/20 text-primary flex items-center justify-center text-sm">1</span>
                        Destination & Dates
                      </h3>
                      
                      <FormField
                        control={form.control}
                        name="destinationId"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Destination</FormLabel>
                            <Select onValueChange={field.onChange} defaultValue={field.value}>
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Choisir une époque" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                {destinations.map((d) => (
                                  <SelectItem key={d.id} value={d.slug}>
                                    {d.title} ({d.era})
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <div className="grid grid-cols-2 gap-4">
                        <FormField
                          control={form.control}
                          name="startDate"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Départ</FormLabel>
                              <FormControl>
                                <Input type="date" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <FormField
                          control={form.control}
                          name="endDate"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Retour</FormLabel>
                              <FormControl>
                                <Input type="date" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>
                    </div>

                    <div className="space-y-4">
                      <h3 className="text-xl font-bold font-display flex items-center gap-2">
                        <span className="w-8 h-8 rounded-full bg-primary/20 text-primary flex items-center justify-center text-sm">2</span>
                        Voyageurs & Confort
                      </h3>
                      
                      <FormField
                        control={form.control}
                        name="groupSize"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Nombre de voyageurs</FormLabel>
                            <FormControl>
                              <Input 
                                type="number" 
                                min={1} 
                                max={6} 
                                {...field} 
                                onChange={e => field.onChange(parseInt(e.target.value))}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="comfortLevel"
                        render={({ field }) => (
                          <FormItem className="space-y-3">
                            <FormLabel>Niveau de confort</FormLabel>
                            <FormControl>
                              <RadioGroup
                                onValueChange={field.onChange}
                                defaultValue={field.value}
                                className="grid grid-cols-1 sm:grid-cols-3 gap-4"
                              >
                                {['standard', 'premium', 'ultra'].map((level) => (
                                  <FormItem key={level}>
                                    <FormControl>
                                      <RadioGroupItem value={level} className="peer sr-only" />
                                    </FormControl>
                                    <Label
                                      className="flex flex-col items-center justify-between rounded-md border-2 border-muted bg-popover p-4 hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-primary [&:has([data-state=checked])]:border-primary cursor-pointer transition-all"
                                    >
                                      <span className="capitalize font-bold text-lg mb-1">{level}</span>
                                      <span className="text-xs text-muted-foreground text-center">
                                        {level === 'standard' && 'Essentiel & Authentique'}
                                        {level === 'premium' && 'Confort Supérieur'}
                                        {level === 'ultra' && 'Luxe Absolu'}
                                      </span>
                                    </Label>
                                  </FormItem>
                                ))}
                              </RadioGroup>
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>

                    <div className="space-y-4">
                      <h3 className="text-xl font-bold font-display flex items-center gap-2">
                        <span className="w-8 h-8 rounded-full bg-primary/20 text-primary flex items-center justify-center text-sm">3</span>
                        Préférences
                      </h3>
                      
                      <FormField
                        control={form.control}
                        name="preferences"
                        render={() => (
                          <FormItem>
                            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                              {preferencesOptions.map((item) => (
                                <FormField
                                  key={item.id}
                                  control={form.control}
                                  name="preferences"
                                  render={({ field }) => {
                                    return (
                                      <FormItem
                                        key={item.id}
                                        className="flex flex-row items-start space-x-3 space-y-0 rounded-md border border-white/5 p-4 bg-white/5"
                                      >
                                        <FormControl>
                                          <Checkbox
                                            checked={field.value?.includes(item.id)}
                                            onCheckedChange={(checked) => {
                                              return checked
                                                ? field.onChange([...field.value, item.id])
                                                : field.onChange(
                                                    field.value?.filter(
                                                      (value: string) => value !== item.id
                                                    )
                                                  )
                                            }}
                                          />
                                        </FormControl>
                                        <FormLabel className="font-normal cursor-pointer w-full">
                                          {item.label}
                                        </FormLabel>
                                      </FormItem>
                                    )
                                  }}
                                />
                              ))}
                            </div>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>

                    <Button 
                      type="submit" 
                      size="lg" 
                      className="w-full h-14 text-lg font-bold bg-primary text-black hover:bg-primary/90 mt-8"
                      disabled={createBooking.isPending}
                    >
                      {createBooking.isPending ? "Traitement..." : "Confirmer la réservation"}
                      {!createBooking.isPending && <ArrowRight className="ml-2 w-5 h-5" />}
                    </Button>
                  </form>
                </Form>
              </CardContent>
            </Card>
          </div>

          {/* Summary / Info */}
          <div className="md:col-span-1">
            <div className="sticky top-24 space-y-6">
              <div className="bg-primary/10 border border-primary/20 rounded-xl p-6">
                <h3 className="font-display font-bold text-xl mb-4 text-primary">Pourquoi réserver maintenant ?</h3>
                <ul className="space-y-3 text-sm text-gray-300">
                  <li className="flex gap-2">
                    <Check className="w-4 h-4 text-primary shrink-0" />
                    Annulation gratuite jusqu'à 24h avant le saut.
                  </li>
                  <li className="flex gap-2">
                    <Check className="w-4 h-4 text-primary shrink-0" />
                    Meilleurs tarifs garantis sur les paradoxes temporels.
                  </li>
                  <li className="flex gap-2">
                    <Check className="w-4 h-4 text-primary shrink-0" />
                    Points de fidélité "Chronos Club" doublés.
                  </li>
                </ul>
              </div>

              <div className="relative overflow-hidden rounded-xl h-64">
                <img 
                  src="https://images.unsplash.com/photo-1504609773096-104ff2c73ba4?q=80&w=2070&auto=format&fit=crop" 
                  alt="Travel preparation" 
                  className="absolute inset-0 w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-black/60 flex items-center justify-center p-6 text-center">
                  <p className="text-white font-display italic text-lg">
                    "Le passé est une terre étrangère : on y fait les choses autrement."
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
