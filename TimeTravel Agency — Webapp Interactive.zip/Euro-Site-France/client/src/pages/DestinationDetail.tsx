import { useRoute, Link } from "wouter";
import { motion } from "framer-motion";
import { ArrowLeft, Calendar, Shield, Cloud, Check, AlertTriangle } from "lucide-react";
import { destinations } from "@shared/schema";
import { Button } from "@/components/ui/button";
import NotFound from "./not-found";

export default function DestinationDetail() {
  const [, params] = useRoute("/destinations/:slug");
  const destination = destinations.find(d => d.slug === params?.slug);

  if (!destination) return <NotFound />;

  return (
    <div className="min-h-screen pb-24">
      {/* Hero Header */}
      <div className="relative h-[60vh] lg:h-[70vh]">
        <div className="absolute inset-0">
          <div className="absolute inset-0 bg-gradient-to-b from-background/30 via-background/60 to-background z-10" />
          <img
            src={destination.image}
            alt={destination.title}
            className="w-full h-full object-cover"
          />
        </div>

        <div className="absolute inset-0 z-20 flex flex-col justify-end pb-12">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full">
            <Link href="/destinations">
              <Button variant="ghost" className="mb-6 text-white/80 hover:text-white hover:bg-white/10 pl-0">
                <ArrowLeft className="mr-2 h-4 w-4" /> Retour au catalogue
              </Button>
            </Link>
            
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
            >
              <span className="inline-block px-4 py-1 mb-4 text-sm font-bold uppercase tracking-widest text-primary bg-black/50 border border-primary/30 rounded-full backdrop-blur-md">
                {destination.era}
              </span>
              <h1 className="font-display text-5xl md:text-7xl font-bold mb-4 text-white">
                {destination.title}
              </h1>
              <div className="flex flex-wrap gap-6 text-lg text-gray-200">
                <div className="flex items-center gap-2">
                  <Calendar className="w-5 h-5 text-primary" />
                  {destination.duration}
                </div>
                <div className="flex items-center gap-2">
                  <Cloud className="w-5 h-5 text-primary" />
                  {destination.weather}
                </div>
                <div className="flex items-center gap-2">
                  <Shield className="w-5 h-5 text-primary" />
                  {destination.riskLevel}
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-12">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-12">
            <section>
              <h2 className="font-display text-3xl font-bold mb-6 text-gradient-gold">L'Expérience</h2>
              <p className="text-xl leading-relaxed text-muted-foreground">
                {destination.description}
              </p>
            </section>

            <section>
              <h2 className="font-display text-3xl font-bold mb-6">À ne pas manquer</h2>
              <div className="grid sm:grid-cols-2 gap-4">
                {destination.highlights.map((highlight, i) => (
                  <div key={i} className="flex items-start gap-3 p-4 bg-card/50 rounded-xl border border-white/5">
                    <div className="mt-1 w-6 h-6 rounded-full bg-primary/20 flex items-center justify-center shrink-0">
                      <Check className="w-3.5 h-3.5 text-primary" />
                    </div>
                    <span className="text-gray-300">{highlight}</span>
                  </div>
                ))}
              </div>
            </section>

            <section className="bg-red-500/5 border border-red-500/20 rounded-2xl p-8">
              <div className="flex items-center gap-3 mb-4 text-red-400">
                <AlertTriangle className="w-6 h-6" />
                <h3 className="font-bold text-xl uppercase tracking-wider">Règles de Sécurité</h3>
              </div>
              <ul className="space-y-3 text-gray-400 list-disc pl-5">
                <li>Ne jamais révéler votre origine temporelle aux locaux.</li>
                <li>Ne consommez aucune nourriture non vérifiée par votre guide.</li>
                <li>Interdiction stricte de ramener des artefacts ou des organismes vivants.</li>
                <li>En cas de paradoxe imminent, activez votre balise de retour d'urgence.</li>
              </ul>
            </section>
          </div>

          {/* Sidebar */}
          <div className="space-y-8">
            <div className="sticky top-24">
              <div className="bg-card border border-white/10 rounded-2xl p-6 shadow-2xl">
                <div className="mb-6 pb-6 border-b border-white/10">
                  <span className="text-sm text-muted-foreground uppercase tracking-widest">Prix par personne</span>
                  <div className="flex items-baseline gap-1 mt-2">
                    <span className="text-4xl font-bold text-white font-display">
                      {destination.basePrice.toLocaleString('fr-FR')} €
                    </span>
                    <span className="text-sm text-muted-foreground">/ séjour</span>
                  </div>
                </div>

                <div className="space-y-4 mb-8">
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Assurance temporelle</span>
                    <span className="text-primary">Incluse</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Guide personnel</span>
                    <span className="text-primary">Inclus</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Vaccins & Implants</span>
                    <span className="text-primary">Inclus</span>
                  </div>
                </div>

                <Link href={`/book?destination=${destination.slug}`}>
                  <Button className="w-full h-12 text-lg font-bold bg-primary text-black hover:bg-primary/90">
                    Planifier ce voyage
                  </Button>
                </Link>
                
                <p className="text-xs text-center text-muted-foreground mt-4">
                  Départ garanti sous réserve de stabilité quantique.
                </p>
              </div>

              <div className="mt-8 bg-blue-500/5 border border-blue-500/20 rounded-xl p-6">
                <h4 className="font-bold text-blue-400 mb-2">Conseil de l'agent</h4>
                <p className="text-sm text-gray-400 italic">
                  "Pour {destination.title}, prévoyez une période d'adaptation sensorielle de 12h à l'arrivée. L'atmosphère est très différente de notre époque."
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
