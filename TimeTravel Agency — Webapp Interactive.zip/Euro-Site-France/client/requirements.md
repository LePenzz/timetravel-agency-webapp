## Packages
framer-motion | Smooth animations for page transitions and interactive elements
lucide-react | Beautiful icons for the UI
date-fns | Date formatting for bookings
react-hook-form | Form handling
@hookform/resolvers | Zod resolvers for form validation
clsx | Class name utility
tailwind-merge | Class merging utility

## Notes
- Dark mode by default with gold accents (#d4af37)
- Google Fonts: 'Playfair Display' for headings, 'Lato' for body
- Chat API available at POST /api/chat
- Booking API available at POST /api/bookings
