import { pgTable, text, serial, integer, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const bookings = pgTable("bookings", {
  id: serial("id").primaryKey(),
  destinationId: text("destination_id").notNull(),
  startDate: text("start_date").notNull(),
  endDate: text("end_date").notNull(),
  groupSize: integer("group_size").notNull(),
  preferences: jsonb("preferences").notNull().$type<string[]>(),
  comfortLevel: text("comfort_level").notNull(), // standard, premium, ultra
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertBookingSchema = createInsertSchema(bookings).omit({ id: true, createdAt: true });

export type InsertBooking = z.infer<typeof insertBookingSchema>;
export type Booking = typeof bookings.$inferSelect;

export const destinations = [
  {
    id: "paris-1889",
    slug: "paris-1889",
    title: "Paris 1889",
    era: "Belle Époque",
    description: "Vivez l'effervescence de la Belle Époque lors de l'Exposition Universelle. Admirez la Tour Eiffel fraîchement achevée et plongez dans le monde des cabarets et de l'art impressionniste.",
    highlights: ["Inauguration de la Tour Eiffel", "Spectacle au Moulin Rouge", "Rencontre avec les artistes montmartrois"],
    riskLevel: "Faible",
    weather: "Doux, averses possibles",
    duration: "3 à 5 jours",
    basePrice: 4500, // Euro
    image: "/images/paris-1889.png",
  },
  {
    id: "cretace",
    slug: "cretace",
    title: "Crétacé",
    era: "-65 Millions d'années",
    description: "Une aventure sauvage et primordiale. Observez les majestueux dinosaures dans leur habitat naturel. Une expédition sécurisée pour les amateurs de sensations fortes.",
    highlights: ["Observation de T-Rex", "Safari en jungle luxuriante", "Nuit en dôme sécurisé"],
    riskLevel: "Élevé",
    weather: "Tropical, très humide",
    duration: "7 jours minimum",
    basePrice: 12000,
    image: "/images/cretace.png",
  },
  {
    id: "florence-1504",
    slug: "florence-1504",
    title: "Florence 1504",
    era: "Renaissance",
    description: "Le berceau de la Renaissance italienne. Marchez sur les traces de Léonard de Vinci et Michel-Ange. Découvrez des chefs-d'œuvre en cours de création.",
    highlights: ["Visite de l'atelier de Michel-Ange", "Banquet au Palais Pitti", "Découverte du David original"],
    riskLevel: "Modéré",
    weather: "Ensoleillé, chaleur agréable",
    duration: "4 à 6 jours",
    basePrice: 6500,
    image: "/images/florence-1504.png",
  }
];
