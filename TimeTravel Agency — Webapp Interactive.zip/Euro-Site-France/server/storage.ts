import { db } from "./db";
import {
  bookings,
  type Booking,
  type InsertBooking,
} from "@shared/schema";

export interface IStorage {
  getBookings(): Promise<Booking[]>;
  createBooking(booking: InsertBooking): Promise<Booking>;
}

export class DatabaseStorage implements IStorage {
  async getBookings(): Promise<Booking[]> {
    return await db.select().from(bookings);
  }

  async createBooking(insertBooking: InsertBooking): Promise<Booking> {
    const [newBooking] = await db.insert(bookings).values(insertBooking).returning();
    return newBooking;
  }
}

export const storage = new DatabaseStorage();
