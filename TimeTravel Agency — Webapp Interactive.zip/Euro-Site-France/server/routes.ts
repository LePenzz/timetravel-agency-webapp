import type { Express } from "express";
import type { Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";

async function seedDatabase() {
  try {
    const existingBookings = await storage.getBookings();
    if (existingBookings.length === 0) {
      await storage.createBooking({
        destinationId: "paris-1889",
        startDate: "2026-05-10",
        endDate: "2026-05-15",
        groupSize: 2,
        preferences: ["art", "gastronomie"],
        comfortLevel: "premium"
      });
      await storage.createBooking({
        destinationId: "cretace",
        startDate: "2026-08-01",
        endDate: "2026-08-15",
        groupSize: 4,
        preferences: ["nature", "aventure"],
        comfortLevel: "ultra"
      });
    }
  } catch (err) {
    console.error("Failed to seed database:", err);
  }
}

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  // Call seed on startup
  seedDatabase();

  app.post(api.bookings.create.path, async (req, res) => {
    try {
      const input = api.bookings.create.input.parse(req.body);
      const booking = await storage.createBooking(input);
      res.status(201).json(booking);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({
          message: err.errors[0].message,
          field: err.errors[0].path.join('.'),
        });
      }
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post(api.chat.send.path, async (req, res) => {
    try {
      const { messages } = api.chat.send.input.parse(req.body);
      
      const apiKey = process.env.MISTRAL_API_KEY || process.env.OPENROUTER_API_KEY || process.env.GROQ_API_KEY;
      
      if (apiKey) {
        try {
          const response = await fetch("https://openrouter.ai/api/v1/chat/completions", {
            method: "POST",
            headers: {
              "Authorization": `Bearer ${apiKey}`,
              "Content-Type": "application/json"
            },
            body: JSON.stringify({
              model: "mistralai/mistral-7b-instruct:free",
              messages: [
                { role: "system", content: "Tu es l'assistant virtuel de TimeTravel Agency, agence de voyage temporel de luxe. Ton ton est professionnel, chaleureux, passionné d'histoire. Tu es un expert fictif crédible. Tu connais parfaitement Paris 1889, Crétacé -65M, Florence 1504. Propose des recommandations. Réponds toujours en français." },
                ...messages
              ]
            })
          });
          
          if (response.ok) {
            const data = await response.json();
            return res.status(200).json({ message: data.choices[0].message.content });
          }
        } catch (e) {
          console.error("AI API failed, falling back to demo mode", e);
        }
      }

      // Demo mode fallback
      const userMessage = messages[messages.length - 1]?.content.toLowerCase() || "";
      
      let reply = "Je suis l'assistant de TimeTravel Agency. Comment puis-je vous aider à planifier votre prochain voyage dans le temps ?";
      
      if (userMessage.includes("paris")) {
        reply = "Paris en 1889 est une destination magnifique ! Vous pourrez y voir la Tour Eiffel fraîchement construite et profiter de la Belle Époque.";
      } else if (userMessage.includes("crétacé") || userMessage.includes("dinosaure") || userMessage.includes("cretace")) {
        reply = "Le Crétacé est parfait pour les amateurs d'aventure. Préparez-vous à une expédition inoubliable parmi les dinosaures !";
      } else if (userMessage.includes("florence") || userMessage.includes("renaissance")) {
        reply = "Florence en 1504 est le berceau de la Renaissance italienne. Idéal pour les amateurs d'art et d'histoire, vous pourrez y suivre les traces de Léonard de Vinci.";
      } else if (userMessage.includes("prix") || userMessage.includes("tarif")) {
        reply = "Nos tarifs débutent à 4 500 € pour Paris 1889, 6 500 € pour Florence 1504, et 12 000 € pour l'expédition au Crétacé.";
      } else if (userMessage.includes("bonjour") || userMessage.includes("salut")) {
        reply = "Bonjour ! Bienvenue chez TimeTravel Agency. Souhaitez-vous découvrir nos destinations ou effectuer une réservation ?";
      }

      res.status(200).json({ message: reply });
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({
          message: err.errors[0].message,
        });
      }
      res.status(500).json({ message: "Internal server error" });
    }
  });

  return httpServer;
}
